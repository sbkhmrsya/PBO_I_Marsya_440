public class Hewan {
    String Nama;
    String Suara;
    String Jenis;

    void Tampilkan (){
        System.out.println("Nama :" + Nama);
        System.out.println("Suara :" + Suara);
        System.out.println("Jenis :" + Jenis);
        System.out.println();

    }
}
